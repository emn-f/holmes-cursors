Holmes OS — Conjunto Completo de Cursores para Windows (15 tipos)
==================================================================

Pastas incluídas:
- dark/   -> Tema escuro Spider-Verse (glitch ciano/vermelho)
- light/  -> Tema claro editorial (cobalto/esmeralda/vermelho)

Cursores incluídos em cada pasta:
- holmes-arrow.cur     -> Seleção normal
- holmes-help.cur      -> Seleção de ajuda
- holmes-work.cur      -> Trabalhando em segundo plano
- holmes-busy.cur      -> Ocupado
- holmes-cross.cur     -> Seleção de precisão
- holmes-text.cur      -> Seleção de texto
- holmes-hand.cur      -> Manuscrito
- holmes-unavail.cur   -> Indisponível
- holmes-vert.cur      -> Redimensionamento vertical
- holmes-horz.cur      -> Redimensionamento horizontal
- holmes-dgn1.cur      -> Redimensionamento diagonal 1
- holmes-dgn2.cur      -> Redimensionamento diagonal 2
- holmes-move.cur      -> Mover
- holmes-alternate.cur -> Seleção alternativa
- holmes-pointer.cur   -> Seleção de link (mira)

Instalação rápida no Windows 10 / 11:
1. Extraia o ZIP.
2. Entre na pasta `dark/` ou `light/`, clique com o botão direito em `install.inf` -> "Instalar" (ou "Mostrar mais opções" -> "Instalar").
3. Abra `main.cpl` (Win+R) -> aba "Ponteiros" -> selecione "Holmes Dark" ou "Holmes Light" em Esquema -> OK.
